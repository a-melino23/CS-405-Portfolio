// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <exception>
#include <iostream>
#include <stdexcept>

// custom exception type used when application-specific business logic fails.
// it derives from std::exception so it can be handled directly or by a general
// std::exception catch block if necessary.
class CustomApplicationException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom application logic failed.";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // throwing a standard C++ exception simulates a recoverable runtime problem.
    // std::runtime_error is derived from std::exception. callers can catch it
    // through the standard exception interface and display what().
    throw std::runtime_error("A standard exception occurred in the extended application logic.");

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // the suspect logic is wrapped in a try block so the program can report the
    // error instead of just terminating abruptly.
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex)
    {
        // catching std::exception allows standard library exceptions to be handled
        // consistently; keeps the original error message through what().
        std::cout << "Standard exception caught in custom application logic: "
            << ex.what() << std::endl;
    }

    // this a custom exception representing an application-specific failure that main()
    // is expected to catch explicitly before the general std::exception handler.
    throw CustomApplicationException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // division by zero is validated before the calculation so the program fails
    // safely with a clear standard exception instead of producing an invalid result.
    if (den == 0.0f)
    {
        throw std::invalid_argument("Division by zero is not allowed.");
    }

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    // since this function is noexcept, exceptions will be handled here.
    // allowing an exception to escape a noexcept function would terminate the program.
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& ex)
    {
        // handler captures only the expected exception type thrown by divide().
        std::cout << "Division exception caught: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // main application flow is wrapped so all expected and unexpected errors
    // are captured and reported instead of crashing immediately.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomApplicationException& ex)
    {
        // custom exception is caught first because it is the most specific type.
        std::cout << "Custom exception caught in main: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex)
    {
        // general standard exceptions are caught after the custom exception.
        std::cout << "Standard exception caught in main: " << ex.what() << std::endl;
    }
    catch (...)
    {
        // catch-all handler is a final safety net for unexpected exception types.
        std::cout << "An unknown exception was caught in main." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
